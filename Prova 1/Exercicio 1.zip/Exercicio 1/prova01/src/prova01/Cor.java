package prova01;

public enum Cor {
	Preto, branco, prata, azul, vermelho;
}
