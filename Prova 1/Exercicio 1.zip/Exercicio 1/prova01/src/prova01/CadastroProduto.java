package prova01;

public interface CadastroProduto {

	void CadastrarProduto();
	void AlterarProduto();
}
